from django.apps import AppConfig


class DjangoTgBotFrameworkConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_tg_bot_framework'
