class UnknownStateClassLocatorError(Exception):
    pass


class TooLongTransitionError(RuntimeError):
    pass
